# -*- coding: utf-8 -*-
import os
import datetime
import pandas as pd
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
##===================================================================================================
##====================================================================================================
def derive_clsSamples(sample_fullpath,featureStartIndex=5,featureEndIndex=0,valid_percent=0.15):
    ##*******************************************************************************************************
    ##**********************************************************************************************************
    reader_df=pd.read_csv(sample_fullpath, header='infer',encoding='utf-8')
    print(f'the total numbers of samples>>>>>>{len(reader_df)}')
    yIndex=featureStartIndex-1
    if featureEndIndex==0:
        trainX, validX, trainY, validY = train_test_split(reader_df.iloc[:,featureStartIndex:], 
                                                        reader_df.iloc[:,yIndex:featureStartIndex],
                                                        test_size=valid_percent, 
                                                        random_state=42,
                                                        stratify=reader_df.iloc[:,yIndex:featureStartIndex])
    else:
        trainX, validX, trainY, validY = train_test_split(reader_df.iloc[:,featureStartIndex:featureEndIndex], 
                                                        reader_df.iloc[:,yIndex:featureStartIndex],
                                                        test_size=valid_percent, 
                                                        random_state=42,
                                                        stratify=reader_df.iloc[:,yIndex:featureStartIndex])
    return trainX, validX, trainY, validY
##===================================================================================================================
def xgb_cls_train_use_gpu(model_fullpath,sample_fullpath):
    
    trainX, validX, trainY, validY=derive_clsSamples(sample_fullpath)
    print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>binary_classify')
    xgboost_classify = XGBClassifier(n_estimators=10000,max_depth=6,learning_rate=0.01,
                                     objective='multi:softmax',booster='gbtree',tree_method='hist',
                                     subsample=0.8,colsample_bytree=0.8,device='cuda',
                                     eval_metric='mlogloss',early_stopping_rounds=30,random_state=42
                                     )     
    xgboost_classify.set_params(predictor="gpu_predictor")
    #----------------------------------------------------------------------------------------------------------
    xgboost_model=xgboost_classify.fit(trainX,trainY.values.ravel(),
                                        eval_set = [(validX,validY.values.ravel())],
                                        verbose = True)
    
    xgboost_model.save_model(model_fullpath)#save model
    print(f'the objective function infered by xgbclassifier is >>>>>>>>>>>>{xgboost_model.objective}')
    print('the following is the xgboost_model.feature_importances_>>>>>>>>>>')
    print(xgboost_model.feature_importances_)
    print("sucessfully!")
#====================================================================================================
if __name__ == '__main__':
    ##***********************************************************************************************
    os.environ["CUDA_VISIBLE_DEVICES"] = '0'
    curTime=datetime.datetime.now().strftime(r'%Y%m%d%H%M')
    ##********************************************************************************************
    model_DIR=r'./taskModel/gpc_china_xgb_trainInfo'
    os.makedirs(model_DIR,exist_ok=True)
    model_fullpath=os.path.join(model_DIR,f'xgboost_cls_model_{curTime}.json')
    sample_fullpath=r''
    #***********************************************************************************************************
    xgb_cls_train_use_gpu(model_fullpath,sample_fullpath)
    ##***********************************************************************************************