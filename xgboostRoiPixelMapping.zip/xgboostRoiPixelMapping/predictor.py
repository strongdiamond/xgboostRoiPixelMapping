# -*- coding: utf-8 -*-
import os
import sys
import gc
import datetime
from pathlib import Path
import numpy as np
from xgboost import XGBClassifier
from osgeo import gdal,gdal_array
##===================================================================================================
##===================================================================================================
def derive_prefixNames(roiImg_dir,imgSuffix):
    if len(imgSuffix)>0:
        imgs_prefix= sorted([(fname.split(imgSuffix)[0],fname) for fname in os.listdir(roiImg_dir)
                                if fname.endswith((".tif",".dat"))])
    else:
        imgs_prefix= sorted([(Path(fname).stem,fname) for fname in os.listdir(roiImg_dir)
                                if fname.endswith((".tif",".dat"))])    
    
    return imgs_prefix
##===================================================================================================
def perform_img_model_predict(model_fullpath,roiImg_DIR,result_DIR,tile_size,roiImgSuffix):
    #***************************************************************************************
    ##*************************************************************************************
    os.environ["CUDA_VISIBLE_DEVICES"] = '0'
    os.makedirs(result_DIR,exist_ok=True)
    if not os.path.exists(model_fullpath):
        print(f'{model_fullpath} does not exist')
        sys.exit(1)
    ##***********************************************************************
    ##>>>>loading xgbModel
    xgb_model=XGBClassifier(tree_method="hist", device="cuda:0")
    xgb_model.load_model(model_fullpath)
    print(f'{model_fullpath} is already loaded successfully')
    ##***********************************************************************
    imgs_prefixNames=derive_prefixNames(roiImg_DIR,roiImgSuffix)
    for item in imgs_prefixNames:
        imgFn_prefix,img_fname=item
        img_fullpath=os.path.join(roiImg_DIR,img_fname)
        img_ds = gdal.Open(img_fullpath,gdal.GA_ReadOnly)
        if img_ds is None:
            print(f'Could not open {img_fullpath}')
            sys.exit(1)
        
        img_npy = img_ds.ReadAsArray()
        img_npy=img_npy.transpose([1,2,0])
        print(type(img_npy))
        print(img_npy.dtype)
        print('*-raster_array.shape-*'*5)
        print(img_npy.shape)
        oh,ow,b = img_npy.shape
        rh, rw = oh % tile_size, ow % tile_size
        
        height_pad = 0 if rh == 0 else tile_size - rh
        width_pad = 0 if rw == 0 else tile_size - rw
        
        padding_h,padding_w=oh+height_pad,ow+width_pad
        padding_img = np.zeros((padding_h,padding_w,b),dtype=img_npy.dtype)
        print('padding.shape=',padding_img.shape)
        padding_img[0:oh,0:ow,:] = img_npy[:,:,:]
        del img_npy
        img_ds.Close()
        del img_ds
        gc.collect()
        #----------------------------------------------------------------------------------------
        mask_whole = np.zeros((padding_h,padding_w),dtype=np.uint8)
        start=datetime.datetime.now()
        ##***********************************************************
        xgb_model.set_params(predictor="gpu_predictor")#gpu-accelerate
        ##********************************************************
        for i in range(0,padding_h,tile_size):
            for j in range(0,padding_w,tile_size):
                tile=padding_img[i:i+tile_size,j:j+tile_size,:]
                tile=tile.reshape((tile_size*tile_size),b)
                tile=tile.astype(np.float64)
                prob=xgb_model.predict(tile)
                pred_label=(prob>0.5).astype(np.uint8)
                mask_whole[i:i+tile_size,j:j+tile_size]=pred_label.reshape(tile_size,tile_size)*128
                del tile

        mask_whole[:,:][np.logical_and(padding_img[:,:,0]==0,padding_img[:,:,1]==0,padding_img[:,:,2]==0)]=0
        del padding_img
        
        result_fullpath=os.path.join(result_DIR,f'{imgFn_prefix}__xgboost.tif')
        gdal_array.SaveArray(mask_whole[0:oh,0:ow], result_fullpath,format='GTiff',
                             prototype=img_fullpath,interleave='band')
                            
        del mask_whole
        gc.collect()
        end=datetime.datetime.now()
        elapse=end-start
        print(f'大图预测花费的时间:{elapse}')
        print(f'{result_fullpath} is derived!!!!')
##===================================================================================================================

#====================================================================================================
if __name__ == '__main__':
    ##***********************************************************************************************
    model_fullpath=f'./taskModel/gpc_china_xgb_trainInfo/xgboost_cls_model_yyyymmddhhmm.json'
    roiImg_DIR=''
    result_DIR=r''
    tile_size=256
    roiImgSuffix=''
    perform_img_model_predict(model_fullpath,roiImg_DIR,result_DIR,tile_size,roiImgSuffix)